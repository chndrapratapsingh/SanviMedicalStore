function add() {
    let popup = document.getElementById("popupoff");
    popup.removeAttribute('id');
    popup.setAttribute('id', 'popupon')
    popup.innerHTML = `<input id="input1" type="file" name="Mediation" id="NewMediation">
    <input id="MediationName" type="text" placeholder="Enter Mediation Name">
    <input id="MediationQuantity" type="number" name="NewMediation" id="NewMediation" placeholder="Enter Quintity Only Number">
    <button onclick="DonePopup()">submit</button>`;
    let blur = document.getElementById("transparentOff");
    blur.removeAttribute("id");
    blur.setAttribute("id","transparentOn");
}

function DonePopup() {
// //work

    let img = document.getElementById("input1").value;
    let name = document.getElementById("MediationName").value;
    // console.log(name)
    let Quintity = document.getElementById("MediationQuantity").value;
    let html = '';
    if(localStorage.getItem('row') == null)
        html = '';
    else
        html = localStorage.getItem('row'); 

    html = html + `<div class="row">
                    <img src="${img}" alt="">
                    <h4>${name}</h4>
                    <p>Quintity <b>${Quintity}</b></p>
                </div>`;
    localStorage.setItem(`row`,html);
    let a = document.getElementById("main1");
    let b = localStorage.getItem("row");
    a.innerHTML = b;
    
// //DonePopupOff
    let popup = document.getElementById("popupon");
    popup.removeAttribute('id');
    popup.setAttribute('id', 'popupoff')
    popup.innerHTML = '';
    
    let blur = document.getElementById("transparentOn");
    blur.removeAttribute("id");
    blur.setAttribute("id","transparentOff");
}

function asideOn() {
    let aside = document.getElementById("asideOff");
    aside.removeAttribute('id');
    aside.setAttribute('id','asideOn');
    aside.innerHTML = ` <div id="AsideTop">
                        <h4>Menu</h4>
                        <button onclick="AsideOff()"><img src="menu.png" alt=""></button>
                        </div>`;
                        
    let blur = document.getElementById("transparentOff");
    blur.removeAttribute("id");
    blur.setAttribute("id","transparentOn");
}

function AsideOff(){
    let aside = document.getElementById("asideOn");
    aside.removeAttribute("id");
    aside.setAttribute('id','asideOff');
    aside.innerHTML = ``;
    
    let blur = document.getElementById("transparentOn");
    blur.removeAttribute("id");
    blur.setAttribute("id","transparentOff");
}